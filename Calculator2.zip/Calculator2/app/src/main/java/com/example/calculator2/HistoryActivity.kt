package com.example.calculator2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class HistoryActivity : AppCompatActivity() {
//    private lateinit var textView: TextView
private lateinit var textView : TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        textView = findViewById( R.id.value)
        val numberList = intent.getSerializableExtra("key")
        textView.text = numberList.toString()
        println(numberList)
//        textView = findViewById(R.id.History)
//        var numberList = intent.getSerializableExtra("key")
//        println(numberList)
//        textView.text = numberList.toString()
    }
}

